=== Aion Assits - Customer Service ===
Tags: aionassists
Stable tag: 1.0
Tested up to: 6.5
Requires at least: 5.0
Requires PHP: 7.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Aion Assists is a GPT powered customer service plugin for your WooCommerce store.

== Description ==
Create solutions for all your customers with the Aion Assists - Customer Service plugin. Provide all support and marketing services with its numerous features. 

== Installation ==
You can easily install your plugin by entering your license key from the Setup Wizard page from the plugin admin settings or by creating a new free license key.

== Frequently Asked Questions ==
Does an OpenAI key need to be added for free users?
- Yes, you can use the plugin with OpenAI key for free license usage.

**Third-Party Service Usage**

This plugin utilizes a third-party service, Aion Assists, for certain functionalities. Below are the details of how this service is used:

- **Authentication Endpoint**: 
  - URL: (https://aionassistsapp.azurewebsites.net/auth)
  - Purpose: Generates a token specific to your license key and basic company information, allowing it to be stored in your site's local database for authentication purposes.

- **Settings Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/auth/settings)
  - Purpose: Saves chatbot settings permissions.

- **Preferences Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/auth/preferences)
  - Purpose: Saves chat response preferences.

- **Sessions Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/auth/sessions)
  - Purpose: Lists all sessions recorded in the database.

- **Get Sessions Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/auth/get-sessions)
  - Purpose: Retrieves details of specific sessions from the database.

- **Get Messages Summary Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/auth/get-messages-summary?sessionId=${sessionId}&licenseId=${licenseId})
  - Purpose: Fetches all conversations associated with the selected session from the database.

  - **Start Session Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/customer/start-session)
  - Purpose: Facilitates the process of obtaining a session number to initiate the chat service for customers.

- **Customer Endpoint**:
  - URL: (https://aionassistsapp.azurewebsites.net/customer)
  - Purpose: Used by customers to write to and receive responses from the chat service.

It's important for users to be aware of this integration for transparency and legal compliance. Please review the terms of use and privacy policies of Aion Assists. (https://www.aionisys.com/privacy-policy/).