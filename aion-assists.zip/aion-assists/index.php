<?php
// Destruam et aedificabo.
?>